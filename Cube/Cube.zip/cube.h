#pragma once

class Cube{

  private:
   int len_;

  public:
    void setLen(int l);
    int getVol();
    int getSA();

};