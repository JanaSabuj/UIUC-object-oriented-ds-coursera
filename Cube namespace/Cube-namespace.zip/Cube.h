#pragma once

namespace sabuj{
class Cube{
  private:
   int len;
  public:
   void set(int l);
   int vol();
};
}